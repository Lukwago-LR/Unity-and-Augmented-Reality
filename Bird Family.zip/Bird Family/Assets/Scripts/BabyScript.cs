using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BabyScript : MonoBehaviour
{
    public float speed = 0.4f;
    public float rotation_damping = 4;
    public Transform MaamaBird;
    // Start is called before the first frame update
    void Start()
    {
        GameObject[] MaamaBirds = GameObject.FindGameObjectsWithTag("MaamaBird");
        int chosenMaamaBird = Random.Range(0, MaamaBirds.Length);
        MaamaBird = MaamaBirds[chosenMaamaBird].GetComponent<Transform>();

    }

    // Update is called once per frame
    void Update()
    {
        //Baby birds rotate towards maamaBird
        var rotation = Quaternion.LookRotation(MaamaBird.transform.position - transform.position);
        this.transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime + rotation_damping);

         //Baby birds follow maamaBird
        this.transform.position = Vector3.MoveTowards(transform.position, MaamaBird.position, Time.deltaTime); 
        
    }
}

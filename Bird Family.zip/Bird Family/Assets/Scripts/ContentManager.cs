using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class ContentManager : MonoBehaviour
{
    public Toggle BirdToggle;
    public GameObject MaamaBirdPrefab;
    public GameObject BabyBirdPrefab;
    private GameObject spawnedBird;
    public Camera ARCamera;

    private List<RaycastResult> raycastResults = new List<RaycastResult>();

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            Debug.Log("Mouse Button Down");
            Ray ray = ARCamera.ScreenPointToRay(Input.mousePosition);

            if(IsPointerOverUI(Input.mousePosition) == false)
            {
                spawnedBird = Instantiate(WhichBird(), ray.origin, Quaternion.identity);
                spawnedBird.GetComponent<Rigidbody>().AddForce(ray.direction*100);                
            }
            
        }        
    }

    public GameObject WhichBird()
    {
        if(BirdToggle.isOn)
        {
            return MaamaBirdPrefab;
        }else
        {
            return BabyBirdPrefab;
        }
    }

    private bool IsPointerOverUI(Vector2 fingerPosition)
    {
        PointerEventData eventDataPosition = new PointerEventData(EventSystem.current);
        eventDataPosition.position = fingerPosition;
        EventSystem.current.RaycastAll(eventDataPosition, raycastResults);
        return raycastResults.Count > 0;
    }
}

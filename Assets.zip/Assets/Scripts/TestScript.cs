using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("God is good all the time");
        
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log("Jesus is alive");
    }
}
